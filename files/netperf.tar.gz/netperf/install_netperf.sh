build_netperf() {
    set -e
    ARCH=`uname -i`
    SrcPath=/tmp/netperf
    myOBJPATH=/usr/bin
    if [ $ARCH = "aarch64" -o $ARCH = "aarch32" ]
    then
        #cp $SrcPath/* ./ -rf
        aclocal -I src/missing/m4
        automake  --add-missing
        autoconf
        autoheader
        ac_cv_func_setpgrp_void=yes ac_cv_func_malloc_0_nonnull=yes ./configure --build=arm-linux     #--host=$ARMCROSS
        make
        cp src/netperf $myOBJPATH
        cp src/netserver $myOBJPATH
    else
        aclocal -I src/missing/m4
        automake  --add-missing
        autoconf
        autoheader
        ./configure
        make
        cp src/netperf $myOBJPATH
        cp src/netserver $myOBJPATH
    fi
}

build_netperf
